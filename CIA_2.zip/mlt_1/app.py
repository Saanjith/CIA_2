from flask import Flask,request,render_template,redirect,url_for,session
import pandas as pd
import pymysql


app=Flask(__name__)
@app.route("/")
def main():
    return render_template("login.html")

@app.route('/login',methods=['POST'])
def login():
    conn=pymysql.connect(host="localhost",
                         port=3306,
                         user="root",
                         password="$Aanjith10",
                         db="ml")
    ulist= [i for i in (request.form.values())]
    uname = str(ulist[0])
    password = str(ulist[1])
    q='select username,password from user where username=\'{}\''.format(uname)
    df = pd.read_sql_query(q, conn)
    if(not(df.empty)):
        if(df.iloc[0,0]==uname and df.iloc[0,1]==password):
            return render_template('index.html')
    return render_template('login.html',msg='Invalid credentials')



if __name__ == '__main__':
    app.run()
    
